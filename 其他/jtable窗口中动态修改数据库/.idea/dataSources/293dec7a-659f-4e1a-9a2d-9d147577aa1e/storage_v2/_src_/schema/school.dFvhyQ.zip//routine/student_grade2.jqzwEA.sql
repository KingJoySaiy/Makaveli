create procedure student_Grade2(IN SDEPT_IN varchar(20))
  BEGIN
    SELECT student.SNO, SNAME, CNAME, GRADE FROM student, SC, course
    WHERE(
      student.SNO = sc.SNO and course.CNO = sc.CNO and SDEPT = SDEPT_IN
    ) order by student.SNO;
  END;

