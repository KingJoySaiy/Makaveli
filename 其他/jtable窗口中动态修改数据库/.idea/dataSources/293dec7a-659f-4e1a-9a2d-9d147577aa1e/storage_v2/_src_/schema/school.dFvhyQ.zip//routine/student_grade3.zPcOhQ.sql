create procedure student_Grade3(IN S_NAME char(10), IN C_NAME varchar(30), OUT RES int)
  BEGIN
    SET @tmp =(
      SELECT GRADE FROM SC, student, course
      WHERE (
        SNAME = S_NAME AND CNAME = C_NAME AND course.CNO = SC.CNO AND student.SNO = SC.SNO
      )
    );
    if @tmp is null then set res = -1;
    else set res = @tmp;
    end if;
  END;

