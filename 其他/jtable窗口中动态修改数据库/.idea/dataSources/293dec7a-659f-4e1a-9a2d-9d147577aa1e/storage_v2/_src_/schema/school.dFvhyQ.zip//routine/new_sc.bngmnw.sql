create procedure new_sc(IN count int)
  begin
    declare sno_count, cno_count, sno_id, cno_id, flag int;
    set @ct = 1000000;     # @ct防止无法继续插入记录, 导致死循环
    create or replace view sno_t as select distinct(sno) from student;
    create or replace view cno_t as select distinct(cno) from course;
    set sno_count = (select count(*) from sno_t);
    set cno_count = (select count(*) from cno_t);

    while count != 0 and @ct != 0 do
      # 插入条件: sno在student中, cno在course中, grade范围0-100
      set sno_id = rand_num(0, sno_count - 1);
      set cno_id = rand_num(0, cno_count - 1);
      set flag = (select count(*) from sc where
        sno = (select sno from sno_t limit sno_id, 1) and
        cno = (select cno from cno_t limit cno_id, 1)
      );
      if flag = 0 then   # 如果sc中按sno_id,cno_id找不到记录, 则进行插入
        insert into sc(sno, cno, grade) values (
        (select sno from sno_t limit sno_id, 1),
        (select cno from cno_t limit cno_id, 1),
        rand_num(0, 100)
        );
        set count = count - 1;
      end if;
      set @ct = @ct - 1;    # 防止死循环
    end while;
  end;

