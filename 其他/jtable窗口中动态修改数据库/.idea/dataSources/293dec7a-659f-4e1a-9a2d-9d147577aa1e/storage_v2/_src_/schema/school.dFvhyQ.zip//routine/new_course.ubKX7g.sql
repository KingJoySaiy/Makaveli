create procedure new_course(IN count int)
  begin
    while count != 0 do
      # 插入条件: 学分1-10, 学期1-8, 学时1-100
      insert into course (cno, cname, CCREDIT, SEMSTER, PERIOD) values (
        rand_string(10), rand_string(30), rand_num(1, 10), rand_num(1, 8), rand_num(1, 100)
      );
      set count = count - 1;
    end while;
  end;

