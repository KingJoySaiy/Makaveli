create function rand_num(l int, r int)
  returns int
  begin
    return round(rand() * (r - l) + l);
  end;

