create procedure student_Grade1()
  SELECT Student.SNO,Sname,Cname,Grade FROM Student,SC,Course
  WHERE Student.SNO = SC.SNO AND SC.CNO = Course.CNO AND SDEPT='计算机系'
  ORDER BY Student.SNO;

