create view cno_t as
  select distinct `school`.`course`.`CNO` AS `cno`
  from `school`.`course`;

