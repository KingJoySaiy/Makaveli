create view is_student as
  select
    `school`.`student`.`SNO`   AS `SNO`,
    `school`.`student`.`SNAME` AS `SNAME`,
    `school`.`student`.`SSEX`  AS `SSEX`,
    `school`.`student`.`SAGE`  AS `SAGE`,
    `school`.`student`.`SDEPT` AS `SDEPT`
  from `school`.`student`
  where `school`.`student`.`SDEPT` = '信息系';

