create procedure new_student(IN count int)
  begin
    declare sex char(2);
    while count != 0 do
      # 插入条件: ssex为'男'或'女', sage范围15-45
      if rand() > 0.5 then set sex = '男';
      else set sex = '女';
      end if;
      insert into student(sno, sname, ssex, sage, sdept) values(
        rand_string(7), rand_string(10), sex, rand_num(15, 45), rand_string(20)
      );
      set count = count - 1;
    end while;
  end;

