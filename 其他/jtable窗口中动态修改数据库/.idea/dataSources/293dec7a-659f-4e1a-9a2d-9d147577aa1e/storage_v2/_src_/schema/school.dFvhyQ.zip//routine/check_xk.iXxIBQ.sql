create procedure check_xk(IN S_NO char(7), IN C_NO char(10), OUT RES int)
  BEGIN
    SET @cct = (
      SELECT COUNT(*) FROM SC WHERE CNO = C_NO
    );
    SET @sct = (
      SELECT COUNT(*) FROM SC WHERE SNO = S_NO
    );
    IF @cct >= @full THEN SET RES = 0;
    ELSEIF @sct >= 3 THEN SET RES = -1;
    ELSE
      BEGIN
        SET RES = 1;
        INSERT INTO SC VALUES (S_NO, C_NO, 60);
      END;
    END IF;
  end;

