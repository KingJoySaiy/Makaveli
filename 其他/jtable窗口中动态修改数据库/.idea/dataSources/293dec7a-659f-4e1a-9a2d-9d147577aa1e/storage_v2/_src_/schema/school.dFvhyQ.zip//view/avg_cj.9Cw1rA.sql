create view avg_cj as
  select
    `school`.`sc`.`SNO`        AS `SNO`,
    avg(`school`.`sc`.`GRADE`) AS `AV`
  from `school`.`sc`
  group by `school`.`sc`.`SNO`
  order by avg(`school`.`sc`.`GRADE`) desc;

