create view sno_t as
  select distinct `school`.`student`.`SNO` AS `sno`
  from `school`.`student`;

