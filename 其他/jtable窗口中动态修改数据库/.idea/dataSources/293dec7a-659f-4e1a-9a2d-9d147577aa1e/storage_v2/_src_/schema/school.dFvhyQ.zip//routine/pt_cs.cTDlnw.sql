create procedure pt_CS(IN sin char(7), IN cin char(10), IN gin smallint(6))
  begin
    set @s_flag = (select count(*) from student where sin = SNO);
    set @c_flag = (select count(*) from course where cin = cno);
    start transaction;
      insert into sc values (sin, cin, gin);
      if @s_flag = 0 or @c_flag = 0 then  # sno和cno其一不在对应表中则rollback
        rollback;
      else commit;
      end if;
  end;

