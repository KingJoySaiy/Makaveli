create view cj_student as
  select distinct
    `school`.`student`.`SNO`   AS `SNO`,
    `school`.`student`.`SNAME` AS `SNAME`,
    `school`.`course`.`CNAME`  AS `CNAME`,
    `school`.`sc`.`GRADE`      AS `GRADE`
  from `school`.`student`
    join `school`.`sc`
    join `school`.`course`
  where `school`.`student`.`SNO` = `school`.`sc`.`SNO` and `school`.`course`.`CNO` = `school`.`sc`.`CNO` and
        `school`.`sc`.`GRADE` < 60;

